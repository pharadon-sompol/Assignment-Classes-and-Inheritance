﻿/*
 * Team Members: 
 * - Apurva Patel
 * - Pharadon Sompol
 * - Sean Leighton
 * - Tyrone Hing
 * 
 * Date: October 10, 2024
 */

namespace Classes_and_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            // Load appliances from file and start main menu loop
            List<Appliance> appliances = LoadAppliances("appliances.txt");

            bool running = true;
            while (running)
            {
                // Display menu options to the user
                Console.WriteLine("Welcome to Modern Appliances!");
                Console.WriteLine("How May We Assist You?");
                Console.WriteLine("1 – Check out appliance");
                Console.WriteLine("2 – Find appliances by brand");
                Console.WriteLine("3 – Display appliances by type");
                Console.WriteLine("4 – Produce random appliance list");
                Console.WriteLine("5 – Save & exit");
                Console.Write("Enter option: ");
                string choice = Console.ReadLine();

                // Handle user selection based on menu choice
                switch (choice)
                {
                    case "1":
                        CheckOutAppliance(appliances);
                        break;
                    case "2":
                        FindByBrand(appliances);
                        break;
                    case "3":
                        DisplayByType(appliances);
                        break;
                    case "4":
                        DisplayRandomList(appliances);
                        break;
                    case "5":
                        // Save data and exit program
                        SaveAppliances(appliances, "appliances.txt");
                        running = false;
                        Console.WriteLine("Changes saved. Exiting...");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        // Loads appliance data from a file and creates appliance objects
        static List<Appliance> LoadAppliances(string filePath)
        {
            List<Appliance> appliances = new List<Appliance>();

            foreach (var line in File.ReadLines(filePath))
            {
                // Split each line and parse appliance details
                var parts = line.Split(';');
                int itemNumber = int.Parse(parts[0]);
                string brand = parts[1];
                int quantity = int.Parse(parts[2]);
                int wattage = int.Parse(parts[3]);
                string color = parts[4];
                decimal price = decimal.Parse(parts[5]);

                // Create specific appliance object based on item type
                switch (itemNumber.ToString()[0])
                {
                    case '1':
                        int numberOfDoors = int.Parse(parts[6]);
                        int height = int.Parse(parts[7]);
                        int width = int.Parse(parts[8]);
                        appliances.Add(new Refrigerator(itemNumber, brand, color, wattage, price, quantity, numberOfDoors, height, width));
                        break;
                    case '2':
                        string grade = parts[6];
                        int batteryVoltage = int.Parse(parts[7]);
                        appliances.Add(new Vacuum(itemNumber, brand, color, wattage, price, quantity, grade, batteryVoltage));
                        break;
                    case '3':
                        double capacity = double.Parse(parts[6]);
                        string roomType = parts[7];
                        appliances.Add(new Microwave(itemNumber, brand, color, wattage, price, quantity, capacity, roomType));
                        break;
                    case '4':
                    case '5':
                        string feature = parts[6];
                        string soundRating = parts[7];
                        appliances.Add(new Dishwasher(itemNumber, brand, color, wattage, price, quantity, feature, soundRating));
                        break;
                    default:
                        Console.WriteLine($"Unknown appliance type for item number {itemNumber}");
                        break;
                }
            }

            return appliances;
        }

        // Checks out an appliance based on user-provided item number
        static void CheckOutAppliance(List<Appliance> appliances)
        {
            Console.Write("Enter the item number of an appliance: ");
            string input = Console.ReadLine();

            // Ensure input is a valid number
            if (!int.TryParse(input, out int itemNumber))
            {
                Console.WriteLine("No appliances found with that item number.");
                return;
            }

            // Find appliance by item number and adjust quantity
            Appliance appliance = appliances.Find(a => a.ItemNumber == itemNumber);

            if (appliance == null)
            {
                Console.WriteLine("No appliances found with that item number.");
            }
            else if (appliance.Quantity > 0)
            {
                appliance.Quantity--;
                Console.WriteLine($"Appliance \"{itemNumber}\" has been checked out.");
            }
            else
            {
                Console.WriteLine("The appliance is not available to be checked out.");
            }
        }

        // Finds and displays appliances matching a given brand
        static void FindByBrand(List<Appliance> appliances)
        {
            Console.Write("Enter brand to search for: ");
            string brand = Console.ReadLine().ToLower();

            // Filter appliances by brand
            var matchedAppliances = appliances.FindAll(a => a.Brand.ToLower() == brand);

            if (matchedAppliances.Count == 0)
            {
                Console.WriteLine("No appliances found for that brand.");
            }
            else
            {
                Console.WriteLine("Matching Appliances:");
                foreach (var appliance in matchedAppliances)
                {
                    Console.WriteLine(appliance);
                }
            }
        }

        // Displays appliances by type based on user input
        static void DisplayByType(List<Appliance> appliances)
        {
            Console.WriteLine("Appliance Types");
            Console.WriteLine("1 – Refrigerators");
            Console.WriteLine("2 – Vacuums");
            Console.WriteLine("3 – Microwaves");
            Console.WriteLine("4 – Dishwashers");
            Console.Write("Enter type of appliance: ");
            string typeOption = Console.ReadLine();

            // Handle display logic for each appliance type
            switch (typeOption)
            {
                case "1":
                    Console.Write("Enter number of doors: 2 (double door), 3 (three doors) or 4 (four doors): ");
                    int doorType = int.Parse(Console.ReadLine());
                    foreach (var appliance in appliances.OfType<Refrigerator>().Where(r => r.NumberOfDoors == doorType))
                    {
                        Console.WriteLine(appliance);
                    }
                    break;
                case "2":
                    Console.Write("Enter battery voltage value. 18 V (low) or 24 V (high): ");
                    int voltage = int.Parse(Console.ReadLine());
                    foreach (var appliance in appliances.OfType<Vacuum>().Where(v => v.BatteryVoltage == voltage))
                    {
                        Console.WriteLine(appliance);
                    }
                    break;
                case "3":
                    Console.Write("Room where the microwave will be installed: K (kitchen) or W (work site): ");
                    string roomType = Console.ReadLine().ToUpper();
                    foreach (var appliance in appliances.OfType<Microwave>().Where(m => m.RoomType.Equals(roomType, StringComparison.OrdinalIgnoreCase)))
                    {
                        Console.WriteLine(appliance);
                    }
                    break;
                case "4":
                    Console.Write("Enter the sound rating of the dishwasher: Qt (Quietest), Qr (Quieter), Qu (Quiet), or M (Moderate): ");
                    string soundRating = Console.ReadLine();
                    foreach (var appliance in appliances.OfType<Dishwasher>().Where(d => d.SoundRating.Equals(soundRating, StringComparison.OrdinalIgnoreCase)))
                    {
                        Console.WriteLine(appliance);
                    }
                    break;
                default:
                    Console.WriteLine("Invalid appliance type.");
                    break;
            }
        }

        // Displays a random list of appliances based on user-specified count
        static void DisplayRandomList(List<Appliance> appliances)
        {
            Console.Write("Enter number of appliances to display: ");
            int count = int.Parse(Console.ReadLine());

            Random random = new Random();
            for (int i = 0; i < count; i++)
            {
                int index = random.Next(appliances.Count);
                Console.WriteLine(appliances[index]);
            }
        }

        // Saves the current appliance list back to the file
        static void SaveAppliances(List<Appliance> appliances, string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var appliance in appliances)
                {
                    writer.WriteLine(appliance.ToString());
                }
            }
        }
    }
}
