namespace Classes_and_Inheritance
{
    // This class is for refrigerators and adds extra details specific to them
    public class Refrigerator : Appliance
    {
        public int NumberOfDoors { get; set; } // How many doors the refrigerator has
        public int Height { get; set; } // Height of the refrigerator
        public int Width { get; set; } // Width of the refrigerator

        // This method sets up a refrigerator with its specific details, along with general appliance info
        public Refrigerator(int itemNumber, string brand, string color, int wattage, decimal price, int quantity, int numberOfDoors, int height, int width)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            NumberOfDoors = numberOfDoors;
            Height = height;
            Width = width;
        }

        // This makes a string with all the refrigerator's details for easy reading
        public override string ToString()
        {
            // Describes the door type based on the number of doors
            string doorType = NumberOfDoors switch
            {
                2 => "Double Door",
                3 => "Three Doors",
                4 => "Four Doors",
                _ => $"{NumberOfDoors} Doors"
            };

            // Creates a formatted string with all the details of the refrigerator
            return $"Item Number: {ItemNumber}\n" +
                   $"Brand: {Brand}\n" +
                   $"Quantity: {Quantity}\n" +
                   $"Wattage: {Wattage}\n" +
                   $"Color: {Color}\n" +
                   $"Price: {Price}\n" +
                   $"Number of Doors: {doorType}\n" +
                   $"Height: {Height}\n" +
                   $"Width: {Width}\n";
        }
    }
}