namespace Classes_and_Inheritance
{
    // This class is for microwaves and includes extra details specific to them
    public class Microwave : Appliance
    {
        public double Capacity { get; set; } // The microwave's cooking capacity (size)
        public string RoomType { get; set; } // Indicates if it's for the kitchen or a work site

        // This method sets up a microwave with its details, along with general appliance info
        public Microwave(int itemNumber, string brand, string color, int wattage, decimal price, int quantity, double capacity, string roomType)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Capacity = capacity;
            RoomType = roomType;
        }

        // This makes a string with all the microwave's details for easy reading
        public override string ToString()
        {
            // Describes where the microwave is meant to be used
            string roomLocation = RoomType.ToUpper() == "K" ? "Kitchen" : "Work Site";

            // Creates a formatted string with all the details of the microwave
            return $"Item Number: {ItemNumber}\n" +
                   $"Brand: {Brand}\n" +
                   $"Quantity: {Quantity}\n" +
                   $"Wattage: {Wattage}\n" +
                   $"Color: {Color}\n" +
                   $"Price: {Price}\n" +
                   $"Capacity: {Capacity}\n" +
                   $"Room Type: {roomLocation}\n";
        }
    }
}