namespace Classes_and_Inheritance
{
    // This class is for vacuums and adds extra details specific to them
    public class Vacuum : Appliance
    {
        public string Grade { get; set; } // The quality or type of the vacuum
        public int BatteryVoltage { get; set; } // The battery voltage (power level) of the vacuum

        // This method sets up a vacuum with specific details, along with general appliance info
        public Vacuum(int itemNumber, string brand, string color, int wattage, decimal price, int quantity, string grade, int batteryVoltage)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Grade = grade;
            BatteryVoltage = batteryVoltage;
        }

        // This makes a string with all the vacuum's details for easy reading
        public override string ToString()
        {
            // Describes the voltage level based on its value
            string voltageLevel = BatteryVoltage == 18 ? "Low" : "High";

            // Creates a formatted string with all the details of the vacuum
            return $"Item Number: {ItemNumber}\n" +
                   $"Brand: {Brand}\n" +
                   $"Quantity: {Quantity}\n" +
                   $"Wattage: {Wattage}\n" +
                   $"Color: {Color}\n" +
                   $"Price: {Price}\n" +
                   $"Grade: {Grade}\n" +
                   $"Battery Voltage: {voltageLevel}\n";
        }
    }
}