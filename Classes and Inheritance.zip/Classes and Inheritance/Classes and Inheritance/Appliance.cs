namespace Classes_and_Inheritance
{
    // This is the main class for all appliances.
    public abstract class Appliance
    {
        // Common details for any appliance
        public int ItemNumber { get; set; } // The appliance's ID number
        public string Brand { get; set; } // The brand name of the appliance
        public int Quantity { get; set; } // How many are available
        public int Wattage { get; set; } // Power in watts
        public string Color { get; set; } // Color of the appliance
        public decimal Price { get; set; } // Price of the appliance

        // This is a special method to set up an appliance with its details
        public Appliance(int itemNumber, string brand, int quantity, int wattage, string color, decimal price)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
        }

        // This method will be customized in each specific appliance class to describe it
        public abstract override string ToString();
    }
}