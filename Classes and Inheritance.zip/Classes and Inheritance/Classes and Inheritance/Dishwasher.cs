namespace Classes_and_Inheritance
{
    // This class is for dishwashers and includes extra details specific to them
    public class Dishwasher : Appliance
    {
        public string Feature { get; set; } // Special feature of the dishwasher
        public string SoundRating { get; set; } // Noise level rating of the dishwasher

        // This method sets up a dishwasher with its details, along with general appliance info
        public Dishwasher(int itemNumber, string brand, string color, int wattage, decimal price, int quantity, string feature, string soundRating)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Feature = feature;
            SoundRating = soundRating;
        }

        // This makes a string with all the dishwasher's details for easy reading
        public override string ToString()
        {
            // Describes the noise level based on the sound rating
            string soundLabel = SoundRating switch
            {
                "Qt" => "Quietest",
                "Qr" => "Quieter",
                "Qu" => "Quiet",
                "M" => "Moderate",
                _ => SoundRating
            };

            // Creates a formatted string with all the details of the dishwasher
            return $"Item Number: {ItemNumber}\n" +
                   $"Brand: {Brand}\n" +
                   $"Quantity: {Quantity}\n" +
                   $"Wattage: {Wattage}\n" +
                   $"Color: {Color}\n" +
                   $"Price: {Price}\n" +
                   $"Feature: {Feature}\n" +
                   $"Sound Rating: {soundLabel}\n";
        }
    }
}